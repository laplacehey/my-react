import DataImport from './DataImport.js'

/**
 * 纯函数：安全解析 JSON / JS 对象
 * @param {string | object} input
 * @returns {object | array} 解析后的 JS 数据
 */
function parseJsonSafe(input) {
  // 1. 如果已经是 JS 对象/数组，直接返回
  if (typeof input === 'object' && input !== null) {
    return JSON.parse(JSON.stringify(input)) // 深拷贝一份，避免污染原数据
  }

  // 2. 如果是字符串，尝试解析
  if (typeof input === 'string') {
    const trimStr = input.trim()
    try {
      return JSON.parse(trimStr)
    } catch (e) {
      throw new Error('JSON 格式无效：' + e.message)
    }
  }

  throw new Error('不支持的数据源类型')
}

/**
 * 导入器：兼容 JSON 字符串 / JS 对象
 */
export default class JSONImport extends DataImport {
  /**
   * 统一解析入口（异步，保持接口兼容）
   * @param {string | object} source JSON字符串 或 JS对象
   * @returns {Promise<object | array>}
   */
  async parse(source) {
    try {
      const data = parseJsonSafe(source)
      this.rawData = data
      return data
    } catch (err) {
      throw new Error(`JSON/JS 解析失败：${err.message}`)
    }
  }
}