/**
 * 数据导入抽象基类
 * 所有导入器统一接口：parse / getRawData / clear
 */
export default class DataImport {
  constructor() {
    this.rawData = null
  }

  async parse(source) {
    throw new Error('子类必须实现 parse 方法')
  }

  getRawData() {
    return this.rawData
  }

  clear() {
    this.rawData = null
  }
}