<template>
  <el-card :title="title">
    <!-- 动态渲染对应规则表单 -->
    <component
      :is="formCompName"
      ref="ruleFormRef"
      :schema="schema"
      :init-data="initConfig"
    />
  </el-card>
</template>

<script setup>
import { ref, computed } from 'vue'
import RuleKeywordForm from './RuleKeywordForm.vue'
import RuleCascaderForm from './RuleCascaderForm.vue'

const props = defineProps({
  /**
   * 规则类型
   * @type {'keyword' | 'cascader'}
   */
  ruleType: {
    type: String,
    required: true,
    validator: (val) => ['keyword', 'cascader'].includes(val)
  },
  /**
   * 全局 Schema 实例
   */
  schema: {
    type: Object,
    required: true
  },
  /**
   * 初始配置（编辑回显数据，新增时传空对象）
   */
  initConfig: {
    type: Object,
    default: () => ({})
  }
})

// 子表单组件实例
const ruleFormRef = ref(null)

// 动态组件
const formCompName = computed(() => {
  return props.ruleType === 'keyword' ? RuleKeywordForm : RuleCascaderForm
})

// 卡片标题
const title = computed(() => {
  return props.ruleType === 'keyword'
    ? '关键词筛选配置'
    : '层级级联菜单配置'
})

/**
 * 统一提取规则
 * 内部执行表单校验 + 数据清洗
 * @returns {Object|null} 规则对象 / 校验失败返回 null
 */
const extractRule = async () => {
  if (!ruleFormRef.value) return null
  return await ruleFormRef.value.extractRule()
}

// 对外暴露统一方法与实例
defineExpose({
  extractRule,
  ruleFormRef
})
</script>