<template>
  <el-form ref="formRef" label-width="140px" style="max-width: 700px" :rules="formRules" :model="formData">
    <el-form-item
      label="规则名称"
      label-placeholder="请输入唯一规则名称，如：按编码筛选"
      prop="ruleName"
    >
      <el-input
        v-model="formData.ruleName"
        placeholder="例如：订单编码关键词筛选"
      />
    </el-form-item>

    <el-form-item
      label="数组路径"
      label-placeholder="选择要筛选的数组所在路径，根节点为 $root"
      prop="arraypath"
    >
      <el-select
        v-model="formData.arraypath"
        placeholder="请选择数组路径"
        style="width: 100%"
      >
        <el-option
          v-for="path in arrayPathList"
          :key="path"
          :label="path"
          :value="path"
        />
      </el-select>
    </el-form-item>

    <el-form-item
      label="匹配字段"
      label-placeholder="选择用于关键词匹配的字段，如 code / id / name"
      prop="fields"
    >
      <el-select
        v-model="formData.fields"
        placeholder="请选择关键词匹配字段"
        style="width: 100%"
        multiple
      >
        <el-option
          v-for="f in fieldOptions"
          :key="f"
          :label="f"
          :value="f"
        />
      </el-select>
    </el-form-item>
  </el-form>
</template>

<script setup>
import { ref, computed, watch, reactive } from 'vue'
import { cleanName } from "../utils/langTools.js"

const formRef = ref(null)

const props = defineProps({
  schema: {
    type: Object,
    required: true
  },
  // 支持外部回显初始化
  initData: {
    type: Object,
    default: () => ({})
  }
})

// 表单数据
const formData = reactive({
  arraypath: props.initData.arraypath ?? "",
  ruleName: props.initData.ruleName ?? "",
  fields: props.initData.fields ?? []
})

const formRules = {
  ruleName:[{ required: true, message: '规则名称不能为空', trigger: 'blur' }],
  arraypath:[{ required: true, message: '请选择数组路径', trigger: 'change' }],
  fields:[{ required: true, message: '请至少选择一个匹配字段', trigger: 'change' }]
}

// 从 Schema 获取路径列表
const arrayPathList = computed(() => {
  return props.schema?.arrayPathList || []
})

// 根据选中路径动态获取字段列表
const fieldOptions = computed(() => {
  return props.schema?.getPathFieldOptions(formData.arraypath) || []
})

// 路径切换刷新字段
watch(() => formData.arraypath, () => {
  // 路径变更清空已选字段，避免脏数据
  formData.fields = []
})


/**
 * 提取规则：全局表单校验 + 数据清洗 + 组装结果
 * @returns {Object|null}
 */
const extractRule = async () => {
  try {
    // 全局表单校验
    await formRef.value.validate()

    // 清洗规则名称
    const safeRuleName = cleanName(formData.ruleName)

    // 返回标准规则结构
    return {
      type: 'keyword',
      ruleName: safeRuleName,
      arraypath: formData.arraypath,
      fields: [...formData.fields],
      raw: { ...formData }
    }
  } catch {
    // 校验失败返回 null
    return null
  }
}

// 对外暴露方法
defineExpose({
  extractRule
})
</script>