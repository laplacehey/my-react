<template>
  <el-card title="关键词筛选配置">
    <el-form label-width="140px" style="max-width: 700px">
      <el-form-item
        label="规则名称"
        label-placeholder="请输入唯一规则名称，如：按编码筛选"
      >
        <el-input
          v-model="factory.config.kwRuleName"
          placeholder="例如：订单编码关键词筛选"
        />
      </el-form-item>

      <el-form-item
        label="数组路径"
        label-placeholder="选择要筛选的数组所在路径，如根节点直接选择''"
      >
        <el-select
          v-model="factory.config.kwArrayPath"
          placeholder="请选择数组路径"
          style="width: 100%"
        >
          <el-option
            v-for="path in arrayPathList"
            :key="path"
            :label="path || '根节点'"
            :value="path"
          />
        </el-select>
      </el-form-item>

      <el-form-item
        label="匹配字段"
        label-placeholder="选择用于关键词匹配的字段，如 code / id / name"
      >
        <el-select
          v-model="factory.config.kwField"
          placeholder="请选择关键词匹配字段"
          style="width: 100%"
        >
          <el-option
            v-for="f in fieldOptions"
            :key="f"
            :label="f"
            :value="f"
          />
        </el-select>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script setup>
const props = defineProps({
  factory: { type: Object, required: true },
  arrayPathList: { type: Array, default: () => [] },
  fieldOptions: { type: Array, default: () => [] }
})
</script>