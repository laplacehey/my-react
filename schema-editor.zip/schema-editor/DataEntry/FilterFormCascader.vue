<template>
  <el-card title="级联菜单配置">
    <el-form label-width="140px" style="max-width: 900px">
      <el-form-item label="规则名称" label-placeholder="唯一名称，用于识别规则">
        <el-input v-model="factory.config.cascRuleName" placeholder="例如：地区级联选择" />
      </el-form-item>

      <el-form-item label="数组路径" label-placeholder="树形数据所在数组路径">
        <el-select v-model="factory.config.cascArrayPath" style="width:100%">
          <el-option v-for="p in arrayPathList" :key="p" :label="p||'根节点'" :value="p" />
        </el-select>
      </el-form-item>

      <el-form-item label="展示字段(label)" label-placeholder="页面显示用字段，如 label / name">
        <el-select v-model="factory.config.labelField" style="width:100%">
          <el-option v-for="f in fieldOptions" :key="f" :label="f" :value="f" />
        </el-select>
      </el-form-item>

      <el-form-item label="值字段(value)" label-placeholder="唯一标识字段，如 code / id">
        <el-select v-model="factory.config.valueField" style="width:100%">
          <el-option v-for="f in fieldOptions" :key="f" :label="f" :value="f" />
        </el-select>
      </el-form-item>

      <el-form-item label="子节点字段(children)" label-placeholder="树形子节点字段名，如 children / items">
        <el-select v-model="factory.config.childrenField" style="width:100%">
          <el-option v-for="f in fieldOptions" :key="f" :label="f" :value="f" />
        </el-select>
      </el-form-item>
    </el-form>
  </el-card>
</template>

<script setup>
const props = defineProps({
  factory: { type: Object, required: true },
  arrayPathList: { type: Array, default: () => [] },
  fieldOptions: { type: Array, default: () => [] }
})
</script>