<template>
  <div class="page" style="padding: 24px; background:#f5f7fa; min-height:100vh">
    <h2>数据筛选编排工具</h2>

    <!-- 1. 数据录入 -->
    <el-card title="数据源录入" style="margin-bottom:20px">
      <el-input
        v-model="factory.config.rawText"
        type="textarea"
        rows="8"
        placeholder="粘贴 JSON/JS 数组/对象"
        clearable
      />
      <el-button @click="parseData" type="primary" style="margin-top:10px">
        解析数据 & 初始化
      </el-button>
    </el-card>


    <template v-if="schema">
      <el-card style="margin-bottom:20px">
        <el-radio-group v-model="filterType" size="large">
          <el-radio label="keyword">关键词筛选</el-radio>
          <el-radio label="cascader">级联菜单筛选</el-radio>
        </el-radio-group>
      </el-card>

      <RuleItem v-for="k in filterOptions" :key="k" :schema="schema" :rule-type="k" />
    </template>

    <!-- 级联选择器列表 -->
    <el-card title="已创建层级菜单" style="margin-bottom:20px" v-if="filterType === 'cascader' && cascaderGroupList.length">
      <div class="group-list">
        <div class="group-item" v-for="(group, idx) in cascaderGroupList" :key="idx">
          <div class="group-name">【{{ group.ruleName }}】</div>
          <el-cascader
            :options="group.options"
            :multiple="group.mode === 'multiPath'"
            :props="group.props"
            clearable
            style="width: 380px"
            @change="group.handleChanged"
          />
          <el-button size="small" type="danger" @click="removeCascaderGroup(idx)">删除</el-button>
        </div>
      </div>
    </el-card>

    <!-- 4. 操作按钮 -->
    <div style="margin:20px 0; display: flex; gap: 12px;">
      <el-button type="success" @click="saveCurrentRule">保存当前配置到规则列表</el-button>
      <el-button @click="exportCfg">导出配置JSON</el-button>
      <el-button type="warning" @click="resetAll">全局重置</el-button>
    </div>

    <!-- 5. 规则列表 -->
    <el-card title="已配置规则列表" style="margin-bottom:20px" v-if="factory.config.rules.length">
      <el-table :data="factory.config.rules" border size="small">
        <el-table-column label="类型" prop="type" min-width="120" />
        <el-table-column label="规则名称" prop="ruleName" min-width="140" />
        <el-table-column label="数组路径" prop="arrayPath" min-width="160" />
        <el-table-column label="配置摘要" prop="summary" min-width="220" />
        <el-table-column label="操作" width="100">
          <template #default="{ $index }">
            <el-button type="danger" size="small" @click="deleteRule($index)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 6. 数据预览 -->
    <el-row :gutter="20" v-if="schema">
      <el-col :span="12">
        <el-card title="原始数据源">
          <pre class="json-box">{{ JSON.stringify(schema._rawData, null, 2) }}</pre>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card title="筛选后数据">
          <pre class="json-box">{{ JSON.stringify(schema.formData.value, null, 2) }}</pre>
        </el-card>
      </el-col>
    </el-row>

    <!-- 7. 调试面板 -->
    <el-card title="调试：当前 config 对象" style="margin-top: 20px">
      <pre style="background:#fff;padding:12px;border-radius:6px;max-height:300px;overflow:auto;">
{{ JSON.stringify(factory.config, null, 2) }}
      </pre>
    </el-card>
  </div>
</template>

<script setup>
import { ref, watch, shallowRef } from 'vue'
import { ElMessage } from 'element-plus'
import FilterFormKeyword from "./FilterFormKeyword.vue"
import FilterFormCascader from './FilterFormCascader.vue'
import { useLinkKeyStore } from '@/stores/linkKeyStore.js'
import Schema, { NormalLinkEdge, CascaderLinkEdge, LinkNode } from '@/schema-editor/schema/index.js'
import { getValueByPath } from '@/schema-editor/utils/pathUtil.js'
import RuleItem from './RuleItem.vue'
const filterOptions = ["keyword", "cascader"]
const props = defineProps({
  factory: { type: Object, required: true }
})

const linkStore = useLinkKeyStore()
const schema = shallowRef(null)
const filterType = ref('keyword')

// 数组路径、字段下拉选项
const arrayPathList = ref([''])
const fieldOptions = ref([])
// 级联组件实例列表
const cascaderGroupList = ref([])

// 规则名称清洗
const cleanRuleName = (str) => {
  if (!str) return ''
  return str.replace(/[\s\u3000,，]/g, '').trim()
}

// 判断规则名是否重复
const isNameExist = (name) => {
  if (!schema.value) return false
  return schema.value._edges.some(edge => edge.alias === name)
}

// 解析数据源 & 初始化 Schema
const parseData = () => {
  try {
    const data = JSON.parse(props.factory.config.rawText.trim())
    if (schema.value) schema.value.destroy()
    schema.value = new Schema({ rawData: data })
    arrayPathList.value = schema.value.arrayPathList || ['']

    const pathOptions = schema.value.getPathOptions()
    const fieldOptions = schema.value.getPathFieldOptions()
    console.log("pathOptions", pathOptions)


    fieldOptions.value = []
    cascaderGroupList.value = []
    ElMessage.success('数据解析成功，已初始化 Schema')
  } catch (e) {
    ElMessage.error('JSON 格式错误，请检查内容')
    console.error(e)
  }
}

// 监听 数组路径变化，自动解析字段下拉选项
watch(
  () => [props.factory.config.kwArrayPath, props.factory.config.cascArrayPath],
  ([kwPath, cascPath]) => {
    const currentPath = filterType.value === 'keyword' ? kwPath : cascPath
    if (!currentPath || !schema.value) {
      fieldOptions.value = []
      return
    }
    const targetData = getValueByPath(schema.value._rawData, currentPath)
    if (Array.isArray(targetData) && targetData[0]) {
      fieldOptions.value = Object.keys(targetData[0])
    }
  },
  { immediate: true }
)

// 关键词输入联动状态存储
watch(
  () => props.factory.config.kwInputVal,
  (val) => {
    const ruleName = cleanRuleName(props.factory.config.kwRuleName)
    if (ruleName) linkStore.setLinkKey(ruleName, val)
  }
)

// 保存当前表单配置到规则列表
const saveCurrentRule = () => {
  const { factory } = props
  const ft = filterType.value
  let ruleName, arrayPath, summary = {}

  if (ft === 'keyword') {
    ruleName = factory.config.kwRuleName
    arrayPath = factory.config.kwArrayPath
    summary = { field: factory.config.kwField }

    // 创建关键词规则至 Schema
    const safeName = cleanRuleName(ruleName)
    if (!safeName || isNameExist(safeName)) {
      return ElMessage.warning('规则名称为空或已存在')
    }
    const edge = new NormalLinkEdge({ path: arrayPath, alias: safeName })
    const node = new LinkNode({ field: factory.config.kwField, link: safeName })
    edge.addChild(node)
    schema.value.addEdge(edge)
  } else {
    ruleName = factory.config.cascRuleName
    arrayPath = factory.config.cascArrayPath
    summary = {
      labelField: factory.config.labelField,
      valueField: factory.config.valueField,
      childrenField: factory.config.childrenField,
      mode: factory.config.cascMode
    }

    // 创建级联规则至 Schema
    const safeName = cleanRuleName(ruleName)
    if (!safeName || isNameExist(safeName)) {
      return ElMessage.warning('规则名称为空或已存在')
    }
    const cascaderConfig = {
      mode: factory.config.cascMode,
      parentIncludeChildren: true,
      labelField: factory.config.labelField,
      valueField: factory.config.valueField,
      childrenField: factory.config.childrenField
    }
    const edge = new CascaderLinkEdge({
      path: arrayPath,
      alias: safeName,
      cascaderConfig
    })
    const node = new LinkNode({ field: factory.config.valueField, link: safeName })
    edge.addChild(node)
    schema.value.addEdge(edge)

    // 生成级联组件配置
    const treeOptions = getValueByPath(schema.value._rawData, arrayPath)
    const propsConfig = {
      label: factory.config.labelField,
      value: factory.config.valueField,
      children: factory.config.childrenField,
      checkStrictly: factory.config.cascMode === 'leafOnly'
    }
    const groupItem = {
      ruleName: safeName,
      linkKey: safeName,
      mode: factory.config.cascMode,
      options: Array.isArray(treeOptions) ? treeOptions : [],
      props: propsConfig,
      handleChanged: (val) => linkStore.setLinkKey(safeName, val)
    }
    cascaderGroupList.value.push(groupItem)
  }

  // 存入 config 规则列表（普通对象）
  factory.config.rules.push({
    type: ft === 'keyword' ? '关键词筛选' : '级联菜单筛选',
    ruleName,
    arrayPath,
    summary: JSON.stringify(summary)
  })
  ElMessage.success('配置已保存到规则列表')
}

// 删除列表规则
const deleteRule = (idx) => {
  props.factory.config.rules.splice(idx, 1)
  ElMessage.success('规则已删除')
}

// 删除级联项
const removeCascaderGroup = (idx) => {
  const group = cascaderGroupList.value[idx]
  const targetEdge = schema.value._edges.find(e => e.alias === group.ruleName)
  if (targetEdge) schema.value.removeEdge(targetEdge)
  linkStore.clearLinkKey(group.linkKey)
  cascaderGroupList.value.splice(idx, 1)
  ElMessage.success('级联菜单已删除')
}

// 导出配置 JSON
const exportCfg = () => {
  const json = props.factory.exportConfigJSON()
  console.log('导出配置：', json)
  ElMessage.success('配置已导出至控制台')
}

// 全局重置
const resetAll = () => {
  props.factory.reset()
  filterType.value = 'keyword'
  schema.value = null
  arrayPathList.value = ['']
  fieldOptions.value = []
  cascaderGroupList.value = []
  linkStore.resetAll()
  ElMessage.success('已全局重置')
}
</script>

<style scoped>
.json-box {
  max-height: 350px;
  overflow: auto;
  background: #fff;
  padding: 12px;
  border-radius: 4px;
  font-size: 12px;
  line-height: 1.6;
  margin: 0;
}
.group-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.group-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px;
  background: #fff;
  border-radius: 4px;
}
.group-name {
  width: 120px;
  font-weight: 500;
  color: #333;
}
</style>