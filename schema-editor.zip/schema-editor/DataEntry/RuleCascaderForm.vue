<template>
  <el-form ref="formRef" label-width="140px" style="max-width: 900px" :model="formData" :rules="formRules">
    <el-form-item
      label="规则名称"
      label-placeholder="请输入唯一规则名称"
      prop="ruleName"
    >
      <el-input
        v-model="formData.ruleName"
        placeholder="例如：地区级联筛选"
      />
    </el-form-item>

    <el-form-item
      label="数组路径"
      label-placeholder="树形数据所在数组路径，根节点为 $root"
      prop="arraypath"
    >
      <el-select
        v-model="formData.arraypath"
        placeholder="请选择数组路径"
        style="width: 100%"
      >
        <el-option
          v-for="path in arrayPathList"
          :key="path"
          :label="path"
          :value="path"
        />
      </el-select>
    </el-form-item>

    <el-form-item
      label="展示字段(label)"
      label-placeholder="页面展示字段，如 label / name"
      prop="labelField"
    >
      <el-select
        v-model="formData.labelField"
        placeholder="请选择展示字段"
        style="width: 100%"
      >
        <el-option
          v-for="f in fieldOptions"
          :key="f"
          :label="f"
          :value="f"
        />
      </el-select>
    </el-form-item>

    <el-form-item
      label="编码字段(value)"
      label-placeholder="唯一标识字段，如 code / id"
      prop="valueField"
    >
      <el-select
        v-model="formData.valueField"
        placeholder="请选择编码字段"
        style="width: 100%"
      >
        <el-option
          v-for="f in fieldOptions"
          :key="f"
          :label="f"
          :value="f"
        />
      </el-select>
    </el-form-item>

    <el-form-item
      label="子节点字段(children)"
      label-placeholder="树形子节点字段，如 children / items"
      prop="childrenField"
    >
      <el-select
        v-model="formData.childrenField"
        placeholder="请选择子节点字段"
        style="width: 100%"
      >
        <el-option
          v-for="f in fieldOptions"
          :key="f"
          :label="f"
          :value="f"
        />
      </el-select>
    </el-form-item>

    <el-form-item label="级联模式">
      <el-select
        v-model="formData.cascMode"
        style="width: 100%"
      >
        <el-option label="单选路径" value="path" />
        <el-option label="多选路径" value="multiPath" />
        <el-option label="仅叶子节点" value="leafOnly" />
      </el-select>
    </el-form-item>
  </el-form>
</template>

<script setup>
import { ref, computed, watch, reactive } from 'vue'
import { cleanName } from "../utils/langTools.js"

const formRef = ref(null)

const props = defineProps({
  schema: {
    type: Object,
    required: true
  },
  // 支持外部初始化/编辑回显
  initData: {
    type: Object,
    default: () => ({})
  }
})

// 表单数据（和关键词表单结构风格统一）
const formData = reactive({
  arraypath: props.initData.arraypath ?? "",
  ruleName: props.initData.ruleName ?? "",
  labelField: props.initData.labelField ?? "",
  valueField: props.initData.valueField ?? "",
  childrenField: props.initData.childrenField ?? "",
  cascMode: props.initData.cascMode ?? "path"
})

const formRules = {
  arraypath:[{ required: true, message: '请选择数组路径', trigger: 'change' }],
  ruleName:[{ required: true, message: '规则名称不能为空', trigger: 'blur' }],
  labelField:[{ required: true, message: '请选择展示字段', trigger: 'change' }],
  valueField:[{ required: true, message: '请选择编码字段', trigger: 'change' }],
  childrenField:[{ required: true, message: '请选择子节点字段', trigger: 'change' }]
}

// 数组路径列表
const arrayPathList = computed(() => {
  return props.schema?.arrayPathList || []
})

// 当前路径对应的字段列表
const fieldOptions = computed(() => {
  return props.schema?.getPathFieldOptions(formData.arraypath) || []
})

// 切换路径，清空字段选择，防止脏数据
watch(() => formData.arraypath, () => {
  formData.labelField = ""
  formData.valueField = ""
  formData.childrenField = ""
})

// ========== 表单校验规则 ==========


/**
 * 提取规则：全局表单校验 → 名称清洗 → 组装标准规则对象
 * @returns {Object|null}
 */
const extractRule = async () => {
  try {
    // Element Plus 全局表单校验
    await formRef.value.validate()

    // 清洗规则名称
    const safeRuleName = cleanName(formData.ruleName)

    // 返回统一格式规则对象
    return {
      type: 'cascader',
      ruleName: safeRuleName,
      arraypath: formData.arraypath,
      labelField: formData.labelField,
      valueField: formData.valueField,
      childrenField: formData.childrenField,
      cascMode: formData.cascMode,
      raw: { ...formData }
    }
  } catch {
    // 校验失败返回 null
    return null
  }
}

// 对外暴露统一方法
defineExpose({
  extractRule
})
</script>