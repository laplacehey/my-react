//src/schema-editor/DataEntryCascaderDemo.vue
<template>
  <div class="demo-wrap" style="padding: 24px; background: #f5f7fa; min-height: 100vh;">
    <h2 style="margin: 0 0 20px;">数据录入 + 多类型筛选</h2>

    <!-- 步骤1：JSON 数据录入 -->
    <el-card title="步骤1：粘贴 JSON 数据源" style="margin-bottom: 20px;">
      <el-input
        v-model="rawJsonText"
        type="textarea"
        rows="8"
        placeholder="粘贴一维/树形 JSON 数据"
        clearable
        style="width: 100%;"
      />
      <el-button type="primary" class="mt-3" @click="initDataAndSchema">
        解析数据 & 初始化 Schema
      </el-button>
    </el-card>

    <!-- 步骤2：选择筛选类型 -->
    <el-card title="步骤2：选择筛选类型" style="margin-bottom: 20px;" v-if="schema">
      <el-radio-group v-model="filterType" size="large">
        <el-radio label="keyword">关键词筛选(按编码)</el-radio>
        <el-radio label="cascader">层级级联菜单</el-radio>
      </el-radio-group>
    </el-card>

    <!-- 关键词筛选区域 -->
    <el-card title="关键词筛选配置 (NormalLinkEdge)" style="margin-bottom: 20px;" v-if="schema && filterType === 'keyword'">
      <el-row :gutter="20" align="middle">
        <el-col :span="6">
          <div class="form-item">
            <label class="form-label">规则名称</label>
            <el-input v-model="kwRuleName" placeholder="请输入规则名称" />
          </div>
        </el-col>
        <el-col :span="6">
          <div class="form-item">
            <label class="form-label">数组路径</label>
            <el-select v-model="kwArrayPath" placeholder="请选择数组路径">
              <el-option
                v-for="path in schema.arrayPathList"
                :key="path"
                :label="path || '根节点'"
                :value="path"
              />
            </el-select>
          </div>
        </el-col>
        <el-col :span="6">
          <div class="form-item">
            <label class="form-label">筛选字段</label>
            <el-select v-model="kwField" placeholder="请选择筛选字段">
              <el-option v-for="f in fieldOptions" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="form-item btn-item">
            <el-button type="success" @click="createKeywordRule">新增关键词规则</el-button>
          </div>
        </el-col>
      </el-row>
    </el-card>

    <el-card title="筛选视图 - 关键词输入(支持多选)" style="margin-bottom: 20px;" v-if="schema && filterType === 'keyword'">
      <div class="form-item inline-item">
        <label class="form-label">关键词输入</label>
        <el-input
          v-model="kwInputVal"
          placeholder="输入内容筛选，多个关键词用英文逗号分隔"
          clearable
          style="width: 400px"
        />
      </div>
    </el-card>

    <!-- 级联菜单配置区域 -->
    <el-card title="层级级联菜单配置 (CascaderLinkEdge)" style="margin-bottom: 20px;" v-if="schema && filterType === 'cascader'">
      <el-row :gutter="16" align="middle" style="margin-bottom: 16px; flex-wrap: wrap;">
        <el-col :span="4">
          <div class="form-item">
            <label class="form-label">规则名称</label>
            <el-input v-model="cascRuleName" placeholder="请输入规则名称" />
          </div>
        </el-col>
        <el-col :span="4">
          <div class="form-item">
            <label class="form-label">数组路径</label>
            <el-select v-model="cascArrayPath" placeholder="请选择数组路径">
              <el-option
                v-for="path in schema.arrayPathList"
                :key="path"
                :label="path || '根节点'"
                :value="path"
              />
            </el-select>
          </div>
        </el-col>
        <el-col :span="3">
          <div class="form-item">
            <label class="form-label">展示字段(label)</label>
            <el-select v-model="labelField" placeholder="选择字段">
              <el-option v-for="f in fieldOptions" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
        </el-col>
        <el-col :span="3">
          <div class="form-item">
            <label class="form-label">编码字段(value)</label>
            <el-select v-model="valueField" placeholder="选择字段">
              <el-option v-for="f in fieldOptions" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
        </el-col>
        <el-col :span="3">
          <div class="form-item">
            <label class="form-label">子节点字段(children)</label>
            <el-select v-model="childrenField" placeholder="选择字段">
              <el-option v-for="f in fieldOptions" :key="f" :label="f" :value="f" />
            </el-select>
          </div>
        </el-col>
        <el-col :span="3">
          <div class="form-item">
            <label class="form-label">级联模式</label>
            <el-select v-model="cascMode" placeholder="选择模式">
              <el-option label="单选路径" value="path" />
              <el-option label="多选路径" value="multiPath" />
              <el-option label="仅叶子节点" value="leafOnly" />
            </el-select>
          </div>
        </el-col>
        <el-col :span="4">
          <div class="form-item btn-item">
            <el-button type="success" @click="addCascaderGroup">新增层级菜单</el-button>
          </div>
        </el-col>
      </el-row>

      <div v-if="cascaderGroupList.length" class="group-list">
        <div class="group-item" v-for="(group, idx) in cascaderGroupList" :key="idx">
          <div class="group-name">【{{ group.ruleName }}】</div>
          <div class="form-item inline-item">
            <label class="form-label">层级选择</label>
            <el-cascader
              :options="group.options"
              :multiple="group.mode === 'multiPath'"
              :props="group.props"
              clearable
              style="width: 380px"
              @change="group.handleChanged"
            />
          </div>
          <el-button size="small" type="danger" @click="removeCascaderGroup(idx)">删除</el-button>
        </div>
      </div>
    </el-card>

    <!-- 所有已建规则列表 -->
    <el-card title="所有已建规则" style="margin-bottom: 20px;" v-if="schema && schema._edges.length">
      <el-table :data="ruleTableData" border size="small">
        <el-table-column prop="ruleName" label="规则名称" min-width="140" />
        <el-table-column prop="linkKey" label="规则编码(中文)" min-width="180" />
        <el-table-column prop="arraypath" label="数组路径" min-width="180" />
        <el-table-column prop="ruleType" label="规则类型" min-width="140" />
        <el-table-column label="操作" width="100">
          <template #default="{ row }">
            <el-button size="small" type="danger" @click="deleteRule(row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 数据预览 -->
    <el-row :gutter="20" v-if="schema">
      <el-col :span="12">
        <el-card title="原始数据源">
          <pre class="json-box">{{ JSON.stringify(schema._rawData, null, 2) }}</pre>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card title="筛选后数据">
          <pre class="json-box">{{ JSON.stringify(schema.formData.value, null, 2) }}</pre>
        </el-card>
      </el-col>
    </el-row>

    <div style="margin-top: 20px;">
      <el-button type="warning" @click="resetAll">全局重置</el-button>
    </div>
  </div>
</template>

<script setup>
import { ref, computed, watch, shallowRef } from 'vue'
import { ElMessage } from 'element-plus'
import { useLinkKeyStore } from '@/stores/linkKeyStore.js'
import Schema, { NormalLinkEdge, CascaderLinkEdge, LinkNode } from '@/schema-editor/schema/index.js'
import { getValueByPath } from '@/schema-editor/utils/pathUtil.js'

const linkStore = useLinkKeyStore()

// 数据清洗：过滤 空格、中英文逗号、全角空格
function cleanRuleName(str) {
  if (!str) return ''
  // 过滤：半角空格、全角空格、英文逗号、中文逗号
  return str.replace(/[\s\u3000,，]/g, '').trim()
}

// 测试JSON
const rawJsonText = ref(`[
  {
    "label": "浙江省",
    "code": "ZJ",
    "desc": "华东沿海省份",
    "children": [
      {
        "label": "杭州市",
        "code": "HZ",
        "desc": "省会城市",
        "children": [
          { "label": "西湖区", "code": "XH", "desc": "著名景区" },
          { "label": "余杭区", "code": "YH", "desc": "电商产业区" }
        ]
      },
      {
        "label": "宁波市",
        "code": "NB",
        "desc": "港口城市",
        "children": [
          { "label": "海曙区", "code": "HS", "desc": "老城区" }
        ]
      }
    ]
  },
  {
    "label": "江苏省",
    "code": "JS",
    "desc": "江南水乡",
    "children": [
      { "label": "南京市", "code": "NJ", "desc": "六朝古都" }
    ]
  }
]`)

const schema = shallowRef(null)
const filterType = ref('keyword')
const fieldOptions = ref([])

// 关键词配置
const kwRuleName = ref('编码关键词筛选')
const kwArrayPath = ref('')
const kwField = ref('code')
const kwInputVal = ref('')

// 级联配置
const cascRuleName = ref('地区级联筛选')
const cascArrayPath = ref('')
const labelField = ref('label')
const valueField = ref('code')
const childrenField = ref('children')
const cascMode = ref('path')

// 级联规则列表
const cascaderGroupList = ref([])

// 规则表格数据
const ruleTableData = computed(() => {
  if (!schema.value) return []
  return schema.value._edges.map(edge => {
    let ruleName = edge.alias
    let linkKey = ''
    edge.children.forEach(node => node.forEachLink(k => linkKey = k))
    return {
      ruleName,
      linkKey,
      arraypath: edge.arraypath,
      ruleType: edge.ruleType === 'normal' ? '关键词筛选' : '层级级联筛选',
      edgeInst: edge
    }
  })
})

// 监听字段列表
watch(cascArrayPath, (path) => {
  if (!path || !schema.value) {
    fieldOptions.value = []
    return
  }
  const targetData = getValueByPath(schema.value._rawData, path)
  if (Array.isArray(targetData) && targetData[0]) {
    fieldOptions.value = Object.keys(targetData[0])
  }
})

watch(kwArrayPath, (path) => {
  if (!path || !schema.value) {
    fieldOptions.value = []
    return
  }
  const targetData = getValueByPath(schema.value._rawData, path)
  if (Array.isArray(targetData) && targetData[0]) {
    fieldOptions.value = Object.keys(targetData[0])
  }
})

// 关键词输入同步
watch(kwInputVal, (val) => {
  const rawName = kwRuleName.value.trim()
  const linkKey = cleanRuleName(rawName)
  if (linkKey) linkStore.setLinkKey(linkKey, val)
})

// 初始化数据
function initDataAndSchema() {
  try {
    const data = JSON.parse(rawJsonText.value.trim())
    if (schema.value) schema.value.destroy()
    schema.value = new Schema({ rawData: data })
    fieldOptions.value = []
    cascaderGroupList.value = []
    ElMessage.success('数据解析成功，Schema 已初始化')
  } catch (e) {
    ElMessage.error('JSON 格式错误，请检查')
    console.error(e)
  }
}

// 校验规则名称是否已存在
function isNameExist(name) {
  if (!schema.value) return false
  return schema.value._edges.some(edge => edge.alias === name)
}

// 创建关键词规则
function createKeywordRule() {
  const rawName = kwRuleName.value.trim()
  const safeName = cleanRuleName(rawName)

  if (!safeName) {
    return ElMessage.warning('规则名称不能为空或仅含空格、逗号等符号')
  }
  if (isNameExist(safeName)) {
    return ElMessage.warning('该规则名称已存在')
  }
  if (!kwArrayPath.value) {
    return ElMessage.warning('请选择数组路径')
  }
  if (!kwField.value) {
    return ElMessage.warning('请选择筛选字段')
  }

  const linkKey = safeName
  const edge = new NormalLinkEdge({ path: kwArrayPath.value, alias: safeName })
  const node = new LinkNode({ field: kwField.value, link: linkKey })
  edge.addChild(node)
  schema.value.addEdge(edge)

  ElMessage.success(`关键词规则新增成功，编码：${linkKey}`)
}

// 新增级联规则
function addCascaderGroup() {
  const rawName = cascRuleName.value.trim()
  const safeName = cleanRuleName(rawName)

  if (!safeName) {
    return ElMessage.warning('规则名称不能为空或仅含空格、逗号等符号')
  }
  if (isNameExist(safeName)) {
    return ElMessage.warning('该规则名称已存在')
  }
  if (!cascArrayPath.value) {
    return ElMessage.warning('请选择数组路径')
  }
  if (!labelField.value || !valueField.value || !childrenField.value) {
    return ElMessage.warning('请完整选择 label / value / children 字段')
  }

  const linkKey = safeName
  const cascaderConfig  = {
    mode: cascMode.value,
    parentIncludeChildren: true,
    labelField: labelField.value,
    valueField: valueField.value,
    childrenField: childrenField.value
  }

  const edge = new CascaderLinkEdge({
    path: cascArrayPath.value,
    alias: safeName,
    cascaderConfig
  })
  const node = new LinkNode({ field: valueField.value, link: linkKey })
  edge.addChild(node)
  schema.value.addEdge(edge)

  const treeOptions = getValueByPath(schema.value._rawData, cascArrayPath.value)
  const props = {
    label: labelField.value,
    value: valueField.value,
    children: childrenField.value,
    checkStrictly: cascMode.value === 'leafOnly'
  }

  const groupItem = {
    ruleName: safeName,
    linkKey,
    mode: cascMode.value,
    options: Array.isArray(treeOptions) ? treeOptions : [],
    props,
    selectedVal: [],
    handleChanged:(val)=>{
      linkStore.setLinkKey(linkKey, val)
    }
  }
  cascaderGroupList.value.push(groupItem)
  ElMessage.success(`层级菜单新增成功，编码：${linkKey}`)
}


// 删除单条级联规则
function removeCascaderGroup(idx) {
  const group = cascaderGroupList.value[idx]
  const targetEdge = schema.value._edges.find(e => e.alias === group.ruleName)
  if (targetEdge) schema.value.removeEdge(targetEdge)
  linkStore.clearLinkKey(group.linkKey)
  cascaderGroupList.value.splice(idx, 1)
  ElMessage.success('已删除该层级菜单')
}

// 删除规则
function deleteRule(row) {
  schema.value.removeEdge(row.edgeInst)
  linkStore.clearLinkKey(row.linkKey)
  ElMessage.success('规则已删除')
}

// 全局重置
function resetAll() {
  rawJsonText.value = ''
  filterType.value = 'keyword'

  kwRuleName.value = '编码关键词筛选'
  kwArrayPath.value = ''
  kwField.value = 'code'
  kwInputVal.value = ''

  cascRuleName.value = '地区级联筛选'
  cascArrayPath.value = ''
  labelField.value = 'label'
  valueField.value = 'code'
  childrenField.value = 'children'
  cascMode.value = 'path'
  cascaderGroupList.value = []

  fieldOptions.value = []
  linkStore.resetAll()
  if (schema.value) schema.value.destroy()
  schema.value = null
  ElMessage.success('已全局重置')
}
</script>

<style scoped>
.json-box {
  max-height: 350px;
  overflow: auto;
  background: #fff;
  padding: 12px;
  border-radius: 4px;
  font-size: 12px;
  line-height: 1.6;
  margin: 0;
}
.mt-3 {
  margin-top: 12px;
}
.group-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}
.group-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 10px;
  background: #fff;
  border-radius: 4px;
}
.group-name {
  width: 120px;
  font-weight: 500;
  color: #333;
}
.form-item {
  display: flex;
  flex-direction: column;
  gap: 4px;
  width: 100%;
}
.form-item.inline-item {
  flex-direction: row;
  align-items: center;
  gap: 12px;
}
.form-label {
  font-size: 13px;
  color: #606266;
  white-space: nowrap;
}
.btn-item {
  justify-content: flex-end;
  padding-top: 18px;
}
:deep(.el-input),
:deep(.el-select) {
  width: 100%;
}
</style>