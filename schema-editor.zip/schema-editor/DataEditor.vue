<template>
  <DateEntry :factory="factory"/>
</template>

<script setup>
// @ts-nocheck
import DateEntry from "./DataEntry/DataEntry.vue"
import DataFactory from './DataFactory/DataFactory.js'
const  factory = new DataFactory()

</script>