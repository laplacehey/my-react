<template>
  <div class="demo-container">
    <h2>Schema 数组联动筛选 Demo</h2>

    <!-- 粘贴区域 -->
    <div class="json-paste-wrap mb-4">
      <el-input
        v-model="customJsonText"
        type="textarea"
        rows="6"
        placeholder="粘贴 JS 对象/数组 或 JSON 字符串"
        style="width: 100%;"
        clearable
      />
      <el-button type="primary" class="mt-2" @click="saveCustomJson">
        保存当前内容
      </el-button>
    </div>

    <!-- 已保存数据选择 -->
    <el-card class="mb-4">
      <template #header>选择已保存 JSON 数据</template>
      <el-radio-group v-model="dataType" @change="initSchema">
        <el-radio
          v-for="item in savedJsonList"
          :key="item.name"
          :label="item.name"
        >
          {{ item.name }}
        </el-radio>
      </el-radio-group>
    </el-card>

    <!-- 联动规则表单 -->
    <el-card class="mb-4">
      <template #header>链路规则配置（新增 / 编辑）</template>
      <el-row :gutter="20">
        <el-col :span="5">
          <el-select v-model="curArrayPath" placeholder="选择数组路径" style="width:100%">
            <el-option
              v-for="path in schema?.arrayPathList || []"
              :key="path"
              :label="path === '' ? '【根节点主数组】' : path"
              :value="path"
            />
          </el-select>
        </el-col>
        <el-col :span="5">
          <el-select
            v-model="curFields"
            multiple
            placeholder="选择筛选字段"
            style="width:100%"
          >
            <el-option
              v-for="field in fieldOptions"
              :key="field"
              :label="field"
              :value="field"
            />
          </el-select>
        </el-col>
        <el-col :span="5">
          <el-input
            v-model="curLinkKey"
            placeholder="联动Key,多个用逗号分隔"
            style="width:100%"
          />
        </el-col>
        <el-col :span="5">
          <el-input
            v-model="curRuleAlias"
            placeholder="规则别名"
            style="width:100%"
          />
        </el-col>
        <el-col :span="4">
          <el-button type="primary" @click="addRule">新增规则</el-button>
          <el-button v-if="editEdgeId" @click="saveEdit">保存编辑</el-button>
          <el-button @click="cancelEdit">取消</el-button>
        </el-col>
      </el-row>
    </el-card>

    <!-- 规则列表（新增别名列） -->
    <el-card class="mb-4">
      <template #header>已配置链路规则</template>
      <el-table :data="ruleTableData" border size="small">
        <el-table-column prop="alias" label="规则别名" min-width="120" />
        <el-table-column prop="arraypath" label="数组路径" min-width="160" />
        <el-table-column prop="fields" label="筛选字段" min-width="120" />
        <el-table-column prop="linkKeys" label="联动Key" min-width="140" />
        <el-table-column label="操作" width="220">
          <template #default="{ row }">
            <el-button size="small" @click="editRule(row)">编辑</el-button>
            <el-button size="small" type="danger" @click="deleteRule(row)">删除</el-button>
            <el-button size="small" type="success" @click="createTestItem(row)">新建测试项</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>

    <!-- 独立测试区域（每条规则单独输入框+标注） -->
    <el-card class="mb-4" v-if="testList.length">
      <template #header>规则测试区（按规则独立测试）</template>
      <div class="test-item" v-for="(item, idx) in testList" :key="idx" style="margin-bottom: 12px;display: flex;align-items: center;gap: 12px;">
        <span style="width: 180px;font-weight: 500;">
          正在测试：{{ item.alias || '未命名规则' }} (Key: {{ item.linkKeys }})
        </span>
        <el-input
          v-model="item.testValue"
          placeholder="输入关键字测试"
          style="width: 400px"
          clearable
        />
      </div>
    </el-card>

    <!-- 原始共用筛选（保留原有，可选） -->
    <el-card class="mb-4">
      <template #header>全局通用筛选（旧版）</template>
      <el-input
        v-model="filterInput"
        placeholder="输入关键字模糊匹配"
        style="width:400px"
        clearable
      />
    </el-card>

    <!-- 数据预览 -->
    <el-row :gutter="20">
      <el-col :span="12">
        <el-card>
          <template #header>原始基准数据 _rawData</template>
          <pre class="json-pre">{{ schema?.rawDataString }}</pre>
        </el-card>
      </el-col>
      <el-col :span="12">
        <el-card>
          <template #header>筛选后响应式数据 formData</template>
          <pre class="json-pre">{{ JSON.stringify(schema?.formData || {}, null, 2) }}</pre>
        </el-card>
      </el-col>
    </el-row>

    <!-- 功能按钮 -->
    <div class="mt-4" style="gap: 10px; display: flex;">
      <el-button @click="resetAllFilter">重置所有筛选</el-button>
      <el-button type="danger" @click="destroySchema">销毁 Schema 实例</el-button>
      <el-button @click="exportCurrentJson">导出当前数据JSON</el-button>
      <el-button type="warning" @click="clearAllTest">清空所有测试项</el-button>
    </div>

    <!-- 命名弹窗 -->
    <el-dialog v-model="nameDialogVisible" title="请输入数据名称" width="400px">
      <el-input v-model="jsonName" placeholder="名称不能为空"></el-input>
      <template #footer>
        <el-button @click="nameDialogVisible = false">取消</el-button>
        <el-button type="primary" @click="confirmSaveJson">确定</el-button>
      </template>
    </el-dialog>
  </div>
</template>
<script setup>
import { ref, computed, onMounted, watch } from 'vue'
import { ElMessage } from 'element-plus'
import Schema, { LinkEdge, LinkNode } from './schema/'
import { useLinkKeyStore } from '@/stores/linkKeyStore.js'
import { getValueByPath } from '@/schema-editor/utils/pathUtil.js'

const linkStore = useLinkKeyStore()

const customJsonText = ref("")
const nameDialogVisible = ref(false)
const jsonName = ref("")
const savedJsonList = ref([])
const dataType = ref("")

let schema = ref(null)
const curArrayPath = ref('')
const curFields = ref([])
const curLinkKey = ref('')
const curRuleAlias = ref('') // 新增：规则别名
const editEdgeId = ref('')
const fieldOptions = ref([])

// 新增：测试项列表（每条规则对应一个独立测试项）
const testList = ref([])

// 规则表格数据（增加别名）
const ruleTableData = computed(() => {
  if (!schema.value) return []
  return schema.value._edges.map(edge => {
    const fields = []
    const linkKeys = []
    edge.children.forEach(node => {
      node.forEachField(f => fields.push(f))
      node.forEachLink(l => linkKeys.push(l))
    })
    return {
      id: edge.id,
      alias: edge.alias || '',
      arraypath: edge.arraypath,
      fields: fields.join(','),
      linkKeys: linkKeys.join(','),
      edgeInst: edge
    }
  })
})

// 旧版全局筛选（保留）
const filterInput = computed({
  get() {
    const keys = schema.value?._linkKeys || []
    return keys.length ? linkStore.linkMap[keys[0]] || '' : ''
  },
  set(val) {
    const keys = schema.value?._linkKeys || []
    keys.forEach(k => {
      linkStore.setLinkKey(k, val)
    })
  }
})

// 监听测试项输入，同步到对应联动Key
watch(testList, (list) => {
  list.forEach(item => {
    const keys = item.linkKeys.split(',').map(k => k.trim()).filter(Boolean)
    keys.forEach(key => {
      linkStore.setLinkKey(key, item.testValue)
    })
  })
}, { deep: true })

// 优先按 JS 字面量解析
function parseByJs(text) {
  try {
    const fn = new Function(`return (${text})`)
    return { success: true, data: fn() }
  } catch (err) {
    return { success: false }
  }
}

function saveCustomJson() {
  const text = customJsonText.value.trim()
  if (!text) {
    ElMessage.warning('请先粘贴内容')
    return
  }

  const res = parseByJs(text)
  if (!res.success) {
    ElMessage.error('解析失败，请检查语法')
    return
  }

  customJsonText.value = JSON.stringify(res.data, null, 2)
  jsonName.value = ""
  nameDialogVisible.value = true
}

function confirmSaveJson() {
  const name = jsonName.value.trim()
  if (!name) {
    ElMessage.warning('数据名称不能为空')
    return
  }
  const rawData = JSON.parse(customJsonText.value.trim())
  savedJsonList.value.unshift({ name, data: rawData })
  dataType.value = name
  nameDialogVisible.value = false
  initSchema()
  ElMessage.success('保存并加载成功')
}

function exportCurrentJson() {
  if (!schema.value?._rawData) {
    ElMessage.warning('暂无数据可导出')
    return
  }
  const jsonStr = JSON.stringify(schema.value._rawData, null, 2)
  const blob = new Blob([jsonStr], { type: 'application/json' })
  const url = URL.createObjectURL(blob)
  const a = document.createElement('a')
  a.href = url
  a.download = `${dataType.value || 'data'}.json`
  a.click()
  URL.revokeObjectURL(url)
}

// 初始化Schema，同时清空测试项
function initSchema() {
  const targetItem = savedJsonList.value.find(item => item.name === dataType.value)
  if (!targetItem) return

  const raw = targetItem.data
  if (schema.value) {
    schema.value.destroy()
  }
  schema.value = new Schema({ rawData: raw })

  curArrayPath.value = ''
  curFields.value = []
  curLinkKey.value = ''
  curRuleAlias.value = ''
  editEdgeId.value = ''
  fieldOptions.value = []
  testList.value = [] // 切换数据清空测试
}

function loadFieldOptions(path) {
  if (!path || !schema.value) return
  const arr = getValueByPath(schema.value._rawData, path)
  if (!Array.isArray(arr) || arr.length === 0) {
    fieldOptions.value = []
    return
  }
  fieldOptions.value = Object.keys(arr[0])
}

// 新增规则（携带别名）
function addRule() {
  if (!curArrayPath.value) {
    ElMessage.warning('请选择数组路径')
    return
  }
  if (curFields.value.length === 0) {
    ElMessage.warning('请选择筛选字段')
    return
  }
  if (!curLinkKey.value.trim()) {
    ElMessage.warning('请输入联动Key')
    return
  }
  const edge = new LinkEdge({
    path: curArrayPath.value,
    alias: curRuleAlias.value
  })
  const node = new LinkNode({
    field: curFields.value.join(','),
    link: curLinkKey.value
  })
  edge.addChild(node)
  schema.value.addEdge(edge)
  ElMessage.success('新增规则成功')
  curFields.value = []
  curLinkKey.value = ''
  curRuleAlias.value = ''
}

// 编辑规则（回显别名）
function editRule(row) {
  editEdgeId.value = row.id
  curArrayPath.value = row.arraypath
  loadFieldOptions(row.arraypath)
  curFields.value = row.fields.split(',')
  curLinkKey.value = row.linkKeys
  curRuleAlias.value = row.alias
}

// 保存编辑（更新别名）
function saveEdit() {
  if (!editEdgeId.value || !schema.value) return
  const edge = schema.value._edges.find(e => e.id === editEdgeId.value)
  if (!edge) return
  edge.arraypath = curArrayPath.value
  edge.alias = curRuleAlias.value
  edge.children.forEach(node => {
    node.updateSelf({
      field: curFields.value.join(','),
      link: curLinkKey.value
    })
  })
  ElMessage.success('编辑保存成功')
  cancelEdit()
}

function cancelEdit() {
  editEdgeId.value = ''
  curArrayPath.value = ''
  curFields.value = []
  curLinkKey.value = ''
  curRuleAlias.value = ''
  fieldOptions.value = []
}

function deleteRule(row) {
  schema.value.removeEdge(row.edgeInst)
  ElMessage.success('删除成功')
}

// 新建独立测试项
function createTestItem(row) {
  // 避免重复创建同规则测试项
  const exist = testList.value.some(item => item.linkKeys === row.linkKeys && item.alias === row.alias)
  if (exist) {
    ElMessage.warning('该规则测试项已存在')
    return
  }
  testList.value.push({
    alias: row.alias,
    linkKeys: row.linkKeys,
    testValue: ''
  })
  ElMessage.success('已创建测试项')
}

// 清空所有测试项
function clearAllTest() {
  testList.value = []
  ElMessage.success('已清空所有测试项')
}

function resetAllFilter() {
  schema.value?.resetFilter()
  // 重置后清空所有测试输入
  testList.value.forEach(item => item.testValue = '')
  ElMessage.success('筛选已重置')
}

function destroySchema() {
  schema.value?.destroy()
  schema.value = null
  testList.value = []
  ElMessage.success('实例已销毁')
}

watch(curArrayPath, (val) => {
  loadFieldOptions(val)
})

onMounted(() => {})
</script>
<style scoped>
.demo-container {
  padding: 20px;
  background: #f5f7fa;
  min-height: 100vh;
}
.mb-4 {
  margin-bottom: 16px;
}
.json-pre {
  max-height: 400px;
  overflow: auto;
  font-size: 12px;
  line-height: 1.5;
  background: #f9f9f9;
  padding: 10px;
  border-radius: 4px;
}
.mt-2 {
  margin-top: 8px;
}
.mt-4 {
  margin-top: 16px;
}
</style>