// src/schema-editor/schema/Schema.js
import { ref, watch } from 'vue'
import { useLinkKeyStore } from '@/stores/linkKeyStore.js'
import { extractAllArrayPaths } from '@/schema-editor/utils/arrayPathExtract.js'
import { generateId } from '@/config/uuid.js'
import { getValueByPath, setValueByPath } from '@/schema-editor/utils/pathUtil.js'
import { cloneDeep, debounce } from 'lodash'

import LinkEdge from './LinkEdge.js'
import NormalLinkEdge from './NormalLinkEdge.js'
import CascaderLinkEdge from './CascaderLinkEdge.js'

export default class Schema {
  constructor(props = {}) {
    const { rawData = {}, id } = props
    this._id = id || generateId()
    this.formData = ref(cloneDeep(rawData))
    this._rawData = cloneDeep(rawData)
    this._rawDataStr = JSON.stringify(this._rawData, null, 2)
    this._edges = []

    this.pathToFieldsMap = new Map()
    this.arrayPathList = extractAllArrayPaths(rawData)

    this._watchStopFn = null
    this._debounceFn = null
    this.updateWatch()

    this.extractPathOptions()
  }
  /**
   * 递归提取所有数组路径 & 对应字段列表
   * 根数组标识：$root
   */
  extractPathOptions() {
    this.arrayPathList = []
    this.pathToFieldsMap.clear()
    const rootPath = '$root'
    // 根节点是数组 → 根路径标记为 $root
    if (Array.isArray(this._rawData)) {
      this.arrayPathList.push(rootPath)
      // 提取根数组字段
      if (this._rawData.length > 0 && this._rawData[0] && typeof this._rawData[0] === 'object') {
        this.pathToFieldsMap.set(rootPath, Object.keys(this._rawData[0]))
      } else {
        this.pathToFieldsMap.set(rootPath, [])
      }
    }

    /**
     * 递归遍历
     * @param {*} data 当前数据
     * @param {string} parentPath 上级路径
     */
    const traverse = (data, parentPath) => {
      if (!data || typeof data !== 'object') return

      Object.keys(data).forEach(key => {
        const val = data[key]
        let currentPath
        // 拼接路径：父路径存在则 父路径.当前key，否则直接key
        currentPath = parentPath ? `${parentPath}.${key}` : key

        // 遇到数组节点
        if (Array.isArray(val)) {
          if (!this.arrayPathList.includes(currentPath)) {
            this.arrayPathList.push(currentPath)
          }
          // 提取当前数组对应的字段
          if (val.length > 0 && val[0] && typeof val[0] === 'object') {
            this.pathToFieldsMap.set(currentPath, Object.keys(val[0]))
          } else {
            this.pathToFieldsMap.set(currentPath, [])
          }
          // 递归数组内部每一项
          val.forEach((item,index) => traverse(item, `${currentPath}.${index}`))
        }
        // 普通对象继续递归
        else if (typeof val === 'object' && val !== null) {
          traverse(val, currentPath)
        }
      })
    }

    // 启动递归：根数组外层不再传空，正常遍历子级
    traverse(this._rawData, rootPath)
  }

  /**
   * 根据路径获取字段列表
   * @param {string} path 数组路径（$root / a.b.c）
   * @returns {string[]}
   */
  getPathFieldOptions(path) {
    return this.pathToFieldsMap.get(path) || []
  }
  
  getPathOptions(path) {
    return [...this.pathToFieldsMap.keys()]
  }

  get rawDataString() {
    return this._rawDataStr
  }

  _onEdgesChanged() {
    this.updateWatch()
  }

  removeEdge(e) {
    if (!(e instanceof LinkEdge)) return
    const idx = this._edges.findIndex(item => item.id === e.id)
    if (idx > -1) {
      this._edges.splice(idx, 1)
      this._onEdgesChanged()
    }
  }

  addEdge(e) {
    if (!(e instanceof LinkEdge)) return
    const idx = this._edges.findIndex(item => item.id === e.id)
    if (idx === -1) {
      this._edges.push(e)
      e.parent = this
      this._onEdgesChanged()
    }
  }

  updateWatch() {
    this.removeWatch()
    this.rebuildWatch()
  }

  rebuildWatch() {
    const watchMap = Object.create(null)

    this._edges.forEach(edge => {
      const arraypath = edge.arraypath
      edge.children.forEach(node => {
        node.forEachLink(linkKey => {
          if (!watchMap[linkKey]) {
            watchMap[linkKey] = []
          }
          watchMap[linkKey].push({ arraypath, edge })
        })
      })
    })

    const linkKeys = Object.keys(watchMap)
    if (linkKeys.length === 0) return

    this._linkKeys = linkKeys
    const linkStore = useLinkKeyStore()

    const handleFilter = () => {
      // 基于原始数据深拷贝计算，不污染源数据
      const calcData = cloneDeep(this._rawData)
      // 逐个规则执行筛选
      this._edges.forEach(edge => {
        const resultArr = edge.filter(calcData, linkStore.linkMap)
        setValueByPath(calcData, edge.arraypath, resultArr)
      })
      // 赋值给响应式视图数据
      this.formData.value = calcData
    }

    this._debounceFn = debounce(handleFilter, 300)

    this._watchStopFn = watch(
      () => linkKeys.map(key => linkStore.linkMap[key]),
      this._debounceFn,
      { deep: true }
    )
  }

  resetFilter() {
    const linkStore = useLinkKeyStore()
    if (Array.isArray(this._linkKeys)) {
      this._linkKeys.forEach(k => {
        linkStore.setLinkKey(k, '')
      })
    }
  }



  toJSON() {
    const raw = {
      id: this._id,
      rawData: this._rawData,
      edges: []
    }
    this._edges.forEach(e => {
      raw.edges.push(e.toJSON())
    })
    return raw
  }

  removeWatch() {
    if (this._debounceFn && typeof this._debounceFn.cancel === 'function') {
      this._debounceFn.cancel()
      this._debounceFn = null
    }
    if (this._watchStopFn) {
      this._watchStopFn()
      this._watchStopFn = null
    }
  }

  destroy() {
    if (this._debounceFn && typeof this._debounceFn.cancel === 'function') {
      this._debounceFn.cancel()
      this._debounceFn = null
    }
    this.removeWatch()
    this._edges.forEach(edge => {
      edge._children = []
      edge._parent = null
    })
    this._edges = []
  }
}

// 反序列化：根据 ruleType 自动创建对应子类
Schema.insFromJson = (jd) => {
  const schema = new Schema(jd)
  if (Array.isArray(jd.edges)) {
    jd.edges.forEach(ed => {
      let edge
      switch (ed.ruleType) {
        case 'cascader':
          edge = CascaderLinkEdge.insFromJson(ed)
          break
        case 'normal':
        default:
          edge = NormalLinkEdge.insFromJson(ed)
          break
      }
      schema.addEdge(edge)
    })
  }
  return schema
}

export function useSchema(jsonData) {
  return Schema.insFromJson(jsonData)
}