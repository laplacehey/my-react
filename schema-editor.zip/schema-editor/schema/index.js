export * from './LinkEdge.js'
export * from './LinkNode.js'
export * from './Schema.js'
export * from './NormalLinkEdge.js'
export * from './CascaderLinkEdge.js'

// 单独转发默认导出，统一别名
export { default as LinkEdge } from './LinkEdge.js'
export { default as LinkNode } from './LinkNode.js'
export { default as Schema } from './Schema.js'
export { default as NormalLinkEdge } from './NormalLinkEdge.js'
export { default as CascaderLinkEdge } from './CascaderLinkEdge.js'

// 保留原有默认导出，兼容历史 import Schema from '@/xxx/schema'
export { default } from './Schema.js'