// src/schema-editor/schema/LinkEdge.js
import { generateId } from '@/config/uuid.js'
import LinkNode from "./LinkNode.js"
import { getValueByPath } from '@/schema-editor/utils/pathUtil.js'

export default class LinkEdge {
  _arraypath = ''
  _children = []
  _parent = null
  alias = ''

  constructor(props = {}) {
    const { path: arraypath = '', alias, id } = props
    this._id = id || generateId()
    this._arraypath = arraypath
    this._children = []
    this.alias = alias
  }

  get id() {
    return this._id
  }

  set parent(p) {
    this._parent = new WeakRef(p)
  }

  get parent() {
    return this._parent?.deref?.() || null
  }

  get arraypath() {
    return this._arraypath
  }

  get children() {
    return [...this._children]
  }

  removeChild(n) {
    if (!(n instanceof LinkNode)) return
    const idx = this._children.findIndex(item => item.id === n.id)
    if (idx > -1) {
      this._children.splice(idx, 1)
      this.onChildrenChanged()
    }
  }

  addChild(n) {
    if (!(n instanceof LinkNode)) return
    const idx = this._children.findIndex(item => item.id === n.id)
    if (idx === -1) {
      this._children.push(n)
      n.parent = this
      this.onChildrenChanged()
    }
  }

  updateArrayPath(arraypath) {
    this._arraypath = arraypath
    this.onChildrenChanged()
  }

  onChildrenChanged() {
    const p = this.parent
    if (typeof p?.updateWatch === "function") {
      p.updateWatch()
    }
  }

  removeSelf() {
    const p = this.parent
    if (typeof p?.removeEdge === "function") {
      p.removeEdge(this)
    }
  }

  toJSON() {
    return {
      arraypath: this._arraypath,
      id: this.id,
      alias: this.alias,
      children: this._children.map(n => n.toJSON())
    }
  }

  /**
   * 统一筛选接口（基类空实现）
   * @param {Object} rawData 完整原始数据
   * @param {Object} linkMap linkKey -> 筛选值 映射
   * @returns {Array} 筛选后的数组
   */
  filter(rawData, linkMap) {
    const sourceArr = getValueByPath(rawData, this.arraypath)
    return Array.isArray(sourceArr) ? [...sourceArr] : []
  }
}

LinkEdge.insFromJson = (jsonD = {}) => {
  const linkEdge = new LinkEdge(jsonD)
  if (Array.isArray(jsonD.children)) {
    jsonD.children.forEach(d => {
      const node = LinkNode.insFromJson(d)
      linkEdge.addChild(node)
    })
  }
  return linkEdge
}