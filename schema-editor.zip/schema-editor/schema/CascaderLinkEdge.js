
// src/schema-editor/schema/CascaderLinkEdge.js
import LinkEdge from './LinkEdge.js'
import { getValueByPath } from '@/schema-editor/utils/pathUtil.js'

export default class CascaderLinkEdge extends LinkEdge {
  constructor(props = {}) {
    super(props)
    this.ruleType = 'cascader'

    // 级联全局配置
    this.cascaderConfig = {
      labelField: 'label',
      valueField: 'value',
      childrenField: 'children',
      // 筛选模式
      /**
       * mode 可选值：
       * path       单选路径（默认）- 精准匹配单条链路
       * multiPath  多选路径 - 支持同时选中多条链路
       * leafOnly   仅叶子节点可选中 + 路径筛选
       */
      mode: 'path',
      // 父节点选中时，是否自动包含全部子节点
      parentIncludeChildren: true,
      ...(props.cascaderConfig || {})
    }
  }

  /**
   * 入口筛选方法
   * @param {Object} rawData 原始数据
   * @param {Object} linkMap 联动键值映射
   * @returns {Array} 筛选后数组
   */
  filter(rawData, linkMap) {
    const sourceArr = getValueByPath(rawData, this.arraypath)
    if (!Array.isArray(sourceArr)) return []

    // 提取当前级联绑定的选中值
    let selectValues = []
    this.children.forEach(node => {
      node.forEachLink(linkKey => {
        const val = linkMap[linkKey]
        if (val) {
          // 统一转为二维数组：[[路径1], [路径2]] 兼容单选/多选
          selectValues = Array.isArray(val[0]) ? val : [val]
        }
      })
    })

    // 无选中值，返回全部数据
    if (selectValues.length === 0) return [...sourceArr]

    const { valueField, childrenField, mode, parentIncludeChildren } = this.cascaderConfig
    let result = []

    // 根据不同模式分支处理
    switch (mode) {
      // 1. 单选路径模式（基础级联）
      case 'path':
        result = this.#filterSinglePath(sourceArr, selectValues[0], valueField, childrenField, parentIncludeChildren)
        break
      // 2. 多选路径模式
      case 'multiPath':
        result = this.#filterMultiPath(sourceArr, selectValues, valueField, childrenField, parentIncludeChildren)
        break
      // 3. 仅叶子节点可选模式
      case 'leafOnly':
        result = this.#filterLeafOnly(sourceArr, selectValues, valueField, childrenField, parentIncludeChildren)
        break
      default:
        result = [...sourceArr]
    }

    return result
  }

  /**
   * 工具：深拷贝节点（避免修改原数据）
   */
  #cloneNode(node) {
    return JSON.parse(JSON.stringify(node))
  }

  /**
   * 工具：判断节点是否为叶子节点
   */
  #isLeaf(node, childrenField) {
    const children = node[childrenField]
    return !Array.isArray(children) || children.length === 0
  }

  // ===================== 模式1：单选路径筛选 =====================
  #filterSinglePath(nodes, pathArr, valueField, childrenField, parentInclude) {
    if (!Array.isArray(pathArr) || pathArr.length === 0) return [...nodes]
    const traverse = (items, level) => {
      const result = []
      const targetVal = pathArr[level]
      for (const item of items) {
        if (item[valueField] !== targetVal) continue

        const clone = this.#cloneNode(item)
        // 未到路径末尾，继续递归子级
        if (level < pathArr.length - 1) {
          const childList = clone[childrenField] || []
          clone[childrenField] = traverse(childList, level + 1)
        }
        // 父节点勾选，强制保留所有子节点
        else if (parentInclude) {
          // 不截断子树，完整保留
        }

        result.push(clone)
      }
      return result
    }

    return traverse(nodes, 0)
  }

  // ===================== 模式2：多选路径筛选 =====================
  #filterMultiPath(nodes, pathList, valueField, childrenField, parentInclude) {
    if (!Array.isArray(pathList) || pathList.length === 0) return [...nodes]
    let finalResult = []

    // 多条路径分别筛选，最后合并去重
    pathList.forEach(path => {
      const singleRes = this.#filterSinglePath(nodes, path, valueField, childrenField, parentInclude)
      singleRes.forEach(item => {
        const exist = finalResult.some(n => n[valueField] === item[valueField])
        if (!exist) finalResult.push(item)
      })
    })

    return finalResult
  }

  // ===================== 模式3：仅叶子节点可选 =====================
  #filterLeafOnly(nodes, pathList, valueField, childrenField, parentInclude) {
    if (!Array.isArray(pathList) || pathList.length === 0) return [...nodes]
    const leafValueSet = new Set()
    // 收集所有选中的叶子值
    pathList.forEach(path => {
      if (path.length) leafValueSet.add(path.at(-1))
    })

    const result = []
    const traverse = (items) => {
      const levelResult = []
      for (const item of items) {
        const clone = this.#cloneNode(item)
        const children = clone[childrenField] || []
        const childRes = traverse(children)

        // 叶子节点：判断是否在选中集合内
        if (this.#isLeaf(clone, childrenField)) {
          if (leafValueSet.has(clone[valueField])) {
            levelResult.push(clone)
          }
        }
        // 非叶子节点
        else {
          clone[childrenField] = childRes
          // 子节点有匹配项 或 父节点勾选连带子节点，则保留当前节点
          if (childRes.length > 0 || parentInclude) {
            levelResult.push(clone)
          }
        }
      }
      return levelResult
    }

    return traverse(nodes)
  }

  // 序列化
  toJSON() {
    const baseJson = super.toJSON()
    return {
      ...baseJson,
      ruleType: this.ruleType,
      cascaderConfig: { ...this.cascaderConfig }
    }
  }

  // 反序列化
  static insFromJson(jsonD = {}) {
    const edge = new CascaderLinkEdge({
      path: jsonD.arraypath,
      alias: jsonD.alias,
      id: jsonD.id,
      cascaderConfig: jsonD.cascaderConfig
    })

    if (Array.isArray(jsonD.children)) {
      import('./LinkNode.js').then(({ default: LinkNode }) => {
        jsonD.children.forEach(d => edge.addChild(LinkNode.insFromJson(d)))
      })
    }
    return edge
  }
}