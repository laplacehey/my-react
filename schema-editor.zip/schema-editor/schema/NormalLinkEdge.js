// src/schema-editor/schema/NormalLinkEdge.js
import LinkEdge from './LinkEdge.js'
import { getValueByPath } from '@/schema-editor/utils/pathUtil.js'

export default class NormalLinkEdge extends LinkEdge {
  constructor(props = {}) {
    super(props)
    this.ruleType = 'normal'
  }

  filter(rawData, linkMap) {
    const sourceArr = getValueByPath(rawData, this.arraypath)
    if (!Array.isArray(sourceArr)) return []

    // 收集当前 Edge 所有 字段-key 映射
    const fieldKeyMap = new Map()
    this.children.forEach(node => {
      const fields = []
      node.forEachField(f => fields.push(f))
      node.forEachLink(linkKey => {
        fieldKeyMap.set(linkKey, fields)
      })
    })

    return sourceArr.filter(item => {
      // 遍历所有关联的 linkKey
      for (const [linkKey, fields] of fieldKeyMap) {
        const filterVal = linkMap[linkKey]
        // 无筛选值，直接放行
        if (filterVal === '' || filterVal == null) continue

        // 统一转为小写字符串比对
        const targetStr = String(filterVal).toLowerCase().trim()
        // 当前项任意一个字段匹配即通过
        const isMatch = fields.some(field => {
          const cellVal = item[field]
          if (cellVal == null) return false
          return String(cellVal).toLowerCase().trim().includes(targetStr)
        })

        if (!isMatch) return false
      }
      return true
    })
  }

  toJSON() {
    const base = super.toJSON()
    return { ...base, ruleType: this.ruleType }
  }

  static insFromJson(jsonD = {}) {
    const edge = new NormalLinkEdge({
      path: jsonD.arraypath,
      alias: jsonD.alias,
      id: jsonD.id
    })
    if (Array.isArray(jsonD.children)) {
      import('./LinkNode.js').then(({ default: LinkNode }) => {
        jsonD.children.forEach(d => {
          const node = LinkNode.insFromJson(d)
          edge.addChild(node)
        })
      })
    }
    return edge
  }
}