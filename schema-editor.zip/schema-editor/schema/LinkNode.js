//src/schema-editor/schema/LinkNode.js
import { generateId } from '@/config/uuid.js'
export default class LinkNode {
  _parent = null
  _field = ''
  _link = ''

  constructor(props = {}) {
    const { field = '', link = '', id } = props
    this._id = id || generateId()
    this._field = field
    this._link = link
  }

  get id() {
    return this._id
  }

  set parent(parent) {
    this._parent = new WeakRef(parent)
  }

  get parent() {
    return this._parent?.deref?.() || null
  }

  get field() {
    return this._field
  }

  get link() {
    return this._link
  }

  toJSON() {
    return {
      id: this._id,
      field: this._field,
      link: this._link
    }
  }

  _forEachVal(val, callback) {
    if (typeof callback !== 'function' || val == null) return
    let arr = []
    if (Array.isArray(val)) {
      arr = val
    } else if (typeof val === 'string') {
      // 分割+去空格+过滤空值
      arr = val.split(',').map(item => item.trim()).filter(Boolean)
    }
    arr.forEach(callback)
  }

  forEachField(callback) {
    this._forEachVal(this._field, callback)
  }

  forEachLink(callback) {
    this._forEachVal(this._link, callback)
  }

  removeSelf() {
    const p = this.parent
    if (typeof p?.removeChild === "function") {
      p.removeChild(this)
    }
  }

  updateSelf({ field, link }) {
    this._field = field
    this._link = link
    const p = this.parent
    if (typeof p?.onChildrenChanged === "function") {
      p.onChildrenChanged()
    }
  }
}

LinkNode.insFromJson = (jsonData = {}) => {
  return new LinkNode(jsonData)
}