import JSONImport from '../data-imports/JSONImport'

export default class DataFactory {
  constructor() {
    // ========================
    // 核心：就是 普通对象！
    // ========================
    this.config = {
      // 数据源
      rawText: '[\n  {\n    "label": "浙江省",\n    "code": "ZJ",\n    "desc": "华东沿海省份",\n    "children": [\n      {\n        "label": "杭州市",\n        "code": "HZ",\n        "desc": "省会城市",\n        "children": [\n          { "label": "西湖区", "code": "XH", "desc": "著名景区" },\n          { "label": "余杭区", "code": "YH", "desc": "电商产业区" }\n        ]\n      },\n      {\n        "label": "宁波市",\n        "code": "NB",\n        "desc": "港口城市",\n        "children": [\n          { "label": "海曙区", "code": "HS", "desc": "老城区" }\n        ]\n      }\n    ]\n  },\n  {\n    "label": "江苏省",\n    "code": "JS",\n    "desc": "江南水乡",\n    "children": [\n      { "label": "南京市", "code": "NJ", "desc": "六朝古都" }\n    ]\n  }\n]',

      // 类型切换
      filterType: 'keyword',

      // 关键词规则
      kwRuleName: '关键词规则', kwArrayPath: '', kwField: '',

      // 级联规则
      cascRuleName: '级联规则', cascArrayPath: '', labelField: '', valueField: '', childrenField: '', cascMode: 'path',

      // 规则列表
      rules: []
    }

    // 导入器
    this.jsonImport = new JSONImport()

    // 运行时数据（不进 config）
    this.schema = null
  }

  /**
   * 从 JSON/JS 解析并覆盖到 config.rawText
   */
  async importData(source) {
    const data = await this.jsonImport.parse(source)
    this.config.rawText = JSON.stringify(data, null, 2)
    return data
  }

  /**
   * 导出配置（普通对象 → JSON）
   */
  exportConfigJSON() {
    return JSON.stringify(this.config, null, 2)
  }

  /**
   * 从配置 JSON 加载（直接覆盖普通对象）
   */
  loadConfigFromJSON(jsonStr) {
    const cfg = parseJsonSafe(jsonStr)
    this.config = { ...this.config, ...cfg }
  }

  /**
   * 清空
   */
  reset() {
    this.config = {
      rawText: '',
      filterType: 'keyword',
      kwRuleName: '关键词规则',
      kwArrayPath: '',
      kwField: '',
      cascRuleName: '级联规则',
      cascArrayPath: '',
      labelField: '',
      valueField: '',
      childrenField: '',
      cascMode: 'path',
      rules: []
    }
    this.schema = null
  }
}