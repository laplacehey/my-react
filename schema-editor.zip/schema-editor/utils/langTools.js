export function cleanName(name){
  return name.replace(/[\s\u3000,，]/g, '').trim()
}