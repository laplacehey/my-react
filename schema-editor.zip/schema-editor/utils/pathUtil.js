//src/utils/pathUtil.js
/**
 * 根据路径取值
 * @param {object|Array} obj 数据源
 * @param {string} path 路径，$root 代表根数组
 */
export function getValueByPath(obj, path) {
  if (path === '$root') return obj
  if (!obj || typeof obj !== 'object') return undefined

  const keys = path.split('.')
  let result = obj
  for (const key of keys) {
    if(key === '$root') continue
    if (result == null) return undefined
    result = result[key]
  }
  return result
}

/**
 * 根据路径赋值
 * @param {object|Array} obj 数据源
 * @param {string} path 路径，$root 代表根数组
 * @param {*} value 新值
 */
export function setValueByPath(obj, path, value) {
  if (path === '$root') {
    if (Array.isArray(obj)) {
      obj.length = 0
      obj.push(...value)
    } else {
      Object.assign(obj, value)
    }
    return
  }
  if (!obj || typeof obj !== 'object') return

  const keys = path.split('.')
  const lastKey = keys.pop()
  let target = obj

  for (const key of keys) {
    if(key === "$root") continue
    if (!target[key]) {
      target[key] = Array.isArray(target) ? [] : {}
    }
    target = target[key]
  }

  if (Array.isArray(target)) {
    target.length = 0
    target.push(...value)
  } else {
    target[lastKey] = value
  }
}
