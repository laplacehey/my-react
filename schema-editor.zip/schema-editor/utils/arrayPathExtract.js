//src/utils/arrayPathExtract.js
import { getValueByPath, setValueByPath } from './pathUtil.js'

/**
 * 递归提取所有数组路径
 * 规则：
 * 1. 仅【根节点 = 数组】时，额外添加 $root
 * 2. 根为对象时，只输出内部数组正常路径
 */
export function extractAllArrayPaths(data, parentPath = '', result = []) {
  // 标记是否为最顶层根节点
  const isRoot = parentPath === ''

  // 场景1：根节点直接是数组 → 先加入 $root
  if (isRoot && Array.isArray(data)) {
    result.push('$root')
    // 继续遍历数组子项
    data.forEach((item, idx) => {
      extractAllArrayPaths(item, `$root.${idx}`, result)
    })
    return result
  }

  // 非对象/数组，终止递归
  if (typeof data !== 'object' || data === null) return result

  // 场景2：普通对象内部的数组，正常记录路径
  if (Array.isArray(data)) {
    result.push(parentPath)
    data.forEach((item, idx) => {
      extractAllArrayPaths(item, `${parentPath}.${idx}`, result)
    })
    return result
  }

  // 遍历普通对象字段
  for (const key in data) {
    const currentPath = parentPath ? `${parentPath}.${key}` : key
    extractAllArrayPaths(data[key], currentPath, result)
  }

  // 路径去重
  return [...new Set(result)]
}

/**
 * 根据数组路径，获取数组项字段列表
 */
export function getArrayItemFields(data, arrayPath) {
  const arr = getValueByPath(data, arrayPath)
  if (!Array.isArray(arr) || arr.length === 0) return []
  const firstItem = arr[0]
  if (typeof firstItem !== 'object' || firstItem === null) return []
  return Object.keys(firstItem)
}

/**
 * 单层数组筛选
 */
export function filterArray(arr, filterVals, filterField = 'id') {
  if (!Array.isArray(arr) || filterVals.length === 0) return arr
  return arr.filter(item => filterVals.includes(item[filterField]))
}

/**
 * 递归筛选嵌套数组 / 树形数组
 */
export function filterNestedArray(data, arrayPath, filterVals, filterField) {
  const targetArr = getValueByPath(data, arrayPath)
  if (!Array.isArray(targetArr)) return data

  const newArr = filterArray(targetArr, filterVals, filterField)
  setValueByPath(data, arrayPath, newArr)

  // 递归处理子数组
  newArr.forEach((item, idx) => {
    if (typeof item === 'object' && item !== null) {
      for (const key in item) {
        const childVal = item[key]
        if (Array.isArray(childVal)) {
          const childPath = `${arrayPath}.${idx}.${key}`
          filterNestedArray(data, childPath, filterVals, filterField)
        }
      }
      // 兼容树形 children
      if (item.children) {
        item.children = filterArray(item.children, filterVals, filterField)
      }
    }
  })

  return data
}
