import { createApp } from 'vue'
import App from './lib/AppTest.vue'
import 'katex/dist/katex.min.css'

createApp(App).mount('#app')
