<template>
  <div class="el-boxer" ref="elBoxer" :id="props.domId">
    <div
      v-if="loading"
      style="padding: 10px; color: red; border: 1px solid cyan"
    >
      Loading...
    </div>
  </div>
</template>
<script setup>
import { onMounted, ref, watch } from "vue";
import { mermaid2Code } from "../render/mermaid2dom.js";
import { svg2dom } from "../render/svg2dom.js";

const elBoxer = ref(null);
const props = defineProps({
  content: {
    type: String,
    required: true,
  },
  domId: {
    type: String,
    required: true,
  },
  loading: {
    type: Boolean,
    default: false,
  },
});

const loading = ref(false);
onMounted(() => {
  loading.value = true;
  renderMermaid(props.content);
});

async function renderMermaid(content) {
  if (!elBoxer.value) return;
  if (!content) return;
  const svgCode = await mermaid2Code(content, props.domId);
  const svgEl = svg2dom(svgCode, "Mermaid-inner-" + props.domId);

  setTimeout(() => {
    console.log("SVG Element created:", svgEl);
    loading.value = false;
    // 添加新的 SVG 元素
    elBoxer.value.appendChild(svgEl);
  }, 1000 * 2);
}
</script>

<style scoped>
.el-boxer {
  border: 1px solid #409eff;
}
</style>
