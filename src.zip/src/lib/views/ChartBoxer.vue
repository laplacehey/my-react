<template>
  <!-- 1. 定义 ECharts 容器（必须指定宽高） -->
  <div ref="chartRef" class="echarts-container" :id="chartId">{{ props.content }}</div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from "vue";
import * as echarts from "echarts";

const props = defineProps({
  content: {
    type: String,
    required: true,
  },
    chartId: {
    type: String,
    required: true,
  },
});

// 2. 获取容器 DOM 引用
const chartRef = ref(null);
// 3. 缓存 ECharts 实例（方便后续更新/销毁）
let chartInstance = null;

const initEcharts = () => {
  if (!chartRef.value) return;
  // 先检查容器尺寸，避免无效初始化
  const dom = chartRef.value;
  const width = dom.clientWidth;
  const height = dom.clientHeight;
  if (width === 0 || height === 0) {
    console.warn("容器尺寸为0，延迟初始化");
    // 延迟 100ms 重试（可根据实际调整）
    setTimeout(initEcharts, 100);
    return;
  }
  // 正常初始化
  chartInstance = echarts.init(dom);
  // 配置图表选项
  const option = {
    tooltip: {},
    title: { text: "Vue 3 + ECharts 基础示例" },
    xAxis: {
      type: "category",
      data: ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"],
    },
    yAxis: { type: "value" },
    series: [
      { name: "销量", type: "bar", data: [120, 200, 150, 80, 70, 110, 130] },
    ],
  };

  // 设置选项并渲染
  chartInstance.setOption(option);
};

// 4. 初始化 ECharts（组件挂载后执行，确保容器已存在）
onMounted(() => {
  initEcharts();

  // 适配窗口大小变化（可选）
  window.addEventListener("resize", handleResize);
});

// 5. 窗口大小适配函数
const handleResize = () => {
  if (chartInstance) {
    chartInstance.resize(); // ECharts 内置适配方法
  }
};

// 6. 组件卸载时清理（关键：避免内存泄漏）
onUnmounted(() => {
  if (chartInstance) {
    chartInstance.dispose(); // 销毁 ECharts 实例
    chartInstance = null;
  }
  window.removeEventListener("resize", handleResize); // 移除事件监听
});
</script>

<style scoped>
/* 必须给容器指定宽高，否则图表无法显示 */
.echarts-container {
  width: 300px;
  height: 300px;
}
</style>
