<template>
    <div class="el-boxer" ref="elBoxer" :id="props.id">
        {{ props.value }}
    </div>
</template>
<script setup>
import { ref } from 'vue';
const elBoxer = ref(null);
const props = defineProps({
  value: {
    type: String,
    required: true
  },
  id:{
    type: String,
    required: true
  }
});

</script>

<style scoped lang="scss">
.el-boxer {
  border: 1px solid #409eff;
}
</style>