AppTest

<script setup>
import { nextTick, onMounted, ref } from "vue";
import { remark } from "remark";
import remarkParse from "remark-parse"; // Markdown → MDAST
import remarkRehype from "remark-rehype";
import rehypeStringify from "rehype-stringify";
import remarkGfm from "remark-gfm";
import remarkMath from "remark-math"; // ✅ 替代 remark-latex
import rehypeKatex from "rehype-katex"; // ✅ 替代 remark-latex
import rehypePrism from "rehype-prism-plus";
import { rehype } from "rehype";
import rehypeSanitize from "rehype-sanitize";
import { toDom } from "hast-util-to-dom";
import DOMPurify from "dompurify";
import { VFile } from "vfile";
import { diffHast, applyPatches } from "./diff/diffHast.js";
import { mermaidPlaceholder } from "./plugins/plugin.mermaid.js";
import StreamManager from "./manager/StreamManager.js";
import { t_full, t_katex,t_mermaid } from "./test/td.js";

// ✅ 正确的处理器链：Markdown → MDAST → HAST → HTML
let processor = remark()
  .use(remarkParse, {
    fencedCode: true,
  })
  .use(remarkGfm)
  .use(remarkMath)
  .use(mermaidPlaceholder, {
    placeholderPrefix: "universal-placeholder-mermaid-",
    renderedFlag: "data-rendered",
  })
  .use(remarkRehype, { passData: true })
  // .use(rehypeKatex)
  .use(rehypePrism, {
    showLineNumbers: true, // ✅ 全局开启行号
    wrapLines: true, // ✅ 自动换行（避免横向滚动）
    ignoreMissing: true, // 👈 关键！忽略未知语言，不抛错
  })
  // .use(rehypeSanitize)
  .use(rehypeStringify);

let testData = `# 快速写作2
## 🖼️ 图片
!Vue.js Logo
## 支持：
- 代码块
\`\`\`js
console.log('Hello!')
\`\`\`
- 列表
- 数学公式 $\\alpha + \\beta$
> 引用内容
`;



// testData = "\n" +
//     "呵呵呵123456789"+
//     "\n"+
//     "### 流程图" +
//     "\n"
// testData = testData2

// testData = "\n" +
//     "### 流程图测试" +
//     "\n" +
//     "```mermaid\n" +
//     "flowchart TD\n" +
//     "    A[\"启动早期发货评估\"] --> B{\"DTRB材料是否齐备?\"}\n" +
//     "    B -- 是 --> C[\"确认BOQ与HLD冻结\"]\n" +
//     "    B -- 否 --> D[\"识别关键假设并备案\"]\n" +
//     "    C --> E[\"检查软件A\"]\n" +
//     "\n"

testData = `## 🖼️ 图片
!Vue.js Logo

## 🧩 代码块（JavaScript）
\`\`\`js
function greet(name) {
  return \`Hello, \${name}!\`;
}

const user = "Alice";
console.log(greet(user)); // 输出: Hello, Alice!
\`\`\`

## 🌐 链接
访问 [Vue 官网](https://vuejs.org) 获取最新文档，或查看 [GitHub 仓库](https://github.com/vuejs/core)。`;

testData = `
## 📋 表格（测试表格样式）
| 名称 | 类型 | 说明 |
|------|------|------|
| Vue | 框架 | 渐进式 JavaScript 框架 |
| Remark | 工具 | Markdown 处理器 |
| Katex | 渲染库 | 高性能 LaTeX 数学公式引擎 |
| Mermaid | 图表 | 用文本生成流程图、时序图等 |

> 💡 所有功能应正确渲染：图片、代码、链接、公式、表格。`;

testData = t_full;

testData = t_mermaid
testData = t_katex;


testData= `
## 图表测试
测试1
[chart:1]
> 💡 呵呵呵呵呵呵。
${t_mermaid}
`
// testData = "质能方程：$$E = mc^2$$ and 行内公式 $$E = mc^2$$";
let vFile = null;
let steamManager = null;
let pos = 0;
let oldHast = null;
const display = ref(null);
const inputVal = ref("");
const htmlOutput = ref("");
let endStream = false;

let mast = null;
let hast = null;

onMounted(async () => {
  vFile = new VFile();
  steamManager = new StreamManager(
    async (str) => {
      // todo: 监听外部事件；驱动占位更新
      console.log("drawMD", str, str.length);
      await drawMD(str);
    },
    {
      idleThreshold: 10,
    },
  );
  // testData = testData.replace("\n", "")
//   steamManager.append(testData)
  mockIterator2();
});

async function drawMD(content) {
  // 1. 渲染成 DOM 节点
  if (endStream) {
    console.log("endDraw");
  }

  if (content.length === 16) {
    // debugger;
  }

  vFile.value = content || inputVal.value;
  mast = processor.parse(vFile);
  hast = await processor.run(mast, vFile);
  let patches = diffHast(oldHast, hast, vFile);

  if (patches.length > 0) {
    console.log("patches", patches);
  }
  await applyPatches(display.value, patches, vFile);
  oldHast = hast;
  await nextTick();
}

function mockIterator2() {
  let delta = 1;
  setTimeout(async () => {
    let val = testData.slice(pos, pos + delta);
    steamManager.append(val);
    if (pos > testData.length) {
      console.log("遍历结束了", vFile);
      endStream = true;
      steamManager.flush(vFile);
      console.log("遍历结束了2", mast, hast);
      return;
    }
    pos += delta;

    await nextTick();
    mockIterator2();
  }, 20);
}
</script>

<template>
  <div style="font-size: 10px">
    <h1>You did it!</h1>

    <!-- ✅ 渲染生成的 HTML -->

    <div v-html="htmlOutput" class="rendered-content"></div>

    <div ref="display" class="rendered-content"></div>

    <!-- 可选：显示源码 -->

    <hr />

    <!--    <h3>原始 Markdown:</h3>-->

    <!--    <pre>{{ markdown }}</pre>-->

    <h3>生成的 HTML:</h3>

    <div>{{ htmlOutput }}</div>
  </div>
</template>
<style scoped>
.rendered-content {
  font-size: 16px;
}
</style>

<style>
.mermaid-svg-container {
  height: 400px;
  & > svg {
    height: 100%;
  }
}

.rendered-content {
  font-size: 16px;
  line-height: 1.7;
  font-family:
    system-ui,
    -apple-system,
    BlinkMacSystemFont,
    "Segoe UI",
    Roboto,
    sans-serif;
}

/* ✅ 表格样式：简洁专业 */

.rendered-content table {
  width: 100%;
  border-collapse: collapse;
  /* 合并边框，避免双线 */
  margin: 1em 0;
  font-size: 1em;
  border: 1px solid #e0e0e0;
}

.rendered-content th,
.rendered-content td {
  padding: 10px 12px;
  text-align: left;
  border-bottom: 1px solid #e0e0e0;
  /* 轻灰分隔线 */
  border-right: 1px solid #e0e0e0;
  /* 轻灰分隔线 */
}

.rendered-content th {
  background-color: #f8f9fa;
  /* 浅灰表头 */
  font-weight: 600;
  color: #333;
}

.rendered-content tr:nth-child(even) {
  background-color: #fafafa;
  /* 偶数行浅底色，提升可读性 */
}

.rendered-content tr:hover {
  background-color: #f0f0f0;
  /* 悬停效果，交互友好 */
}

/* ✅ 保持代码块样式不变（你原来的）*/

.rendered-content pre {
  background-color: #2d3748 !important;
  color: #e2e8f0 !important;
  padding: 12px !important;
  border-radius: 8px !important;
  overflow-x: auto !important;
  margin: 1em 0 !important;
  font-size: 14px !important;
  line-height: 1.5 !important;
}

.rendered-content .line-numbers-rows {
  color: #6b7280 !important;
  border-right-color: rgba(255, 255, 255, 0.1) !important;
}

/* ✅ 代码行内样式 */

.rendered-content code {
  padding: 2px 6px;
  border-radius: 4px;
  font-size: 0.9em;
}

/* ✅ 引用块 */

.rendered-content blockquote {
  border-left: 4px solid #ccc;
  margin-left: 0;
  padding-left: 16px;
  color: #666;
  background-color: #fcfcfc;
  border-radius: 0 4px 4px 0;
}
</style>
